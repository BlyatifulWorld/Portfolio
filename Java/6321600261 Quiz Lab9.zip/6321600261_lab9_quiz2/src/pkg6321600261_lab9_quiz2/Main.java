package pkg6321600261_lab9_quiz2;

public class Main {

    public static void main(String[] args) {
        Subject oop = new Subject("02739214", "OOP", 4);
        
        Subject dm = new Subject();
        dm.setId("02739435");
        dm.setSubjectName("Data Mining");
        dm.setCredits(3);
        
        Subject gp = new Subject("02739427", "Game Programming", 3);
    }
}
