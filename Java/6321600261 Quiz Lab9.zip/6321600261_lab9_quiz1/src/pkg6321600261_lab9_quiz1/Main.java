package pkg6321600261_lab9_quiz1;

public class Main {

    public static void main(String[] args) {
        Student tanjiro = new Student("001", "Tanjiro", "Engineer", 3.12);
        Student john = new Student();
            john.setId("002");
            john.setName("John");
            john.setMajor("Physics");
            john.setGpax(2.7);
        Student noah = new Student("003", "Noah", "Art", 2.6);
        Student tay = new Student("004", "Tay", "IT", 3.5);
    }
}
