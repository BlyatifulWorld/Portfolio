/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6321600261_lecture8_quiz3;

/**
 *
 * @author Tay
 */
public class Subject {
    public String id;
    public String subjectName;
    public int credits;
}