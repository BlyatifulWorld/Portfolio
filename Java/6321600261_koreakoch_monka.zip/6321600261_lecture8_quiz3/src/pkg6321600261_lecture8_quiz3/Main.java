/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6321600261_lecture8_quiz3;

/**
 *
 * @author Tay
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Subject oop = new Subject();
        oop.id = "02739214";
        oop.subjectName = "OOP";
        oop.credits = 4;
        
        Subject dm = new Subject();
        dm.id = "02739435";
        dm.subjectName = "Data Mining";
        dm.credits = 3;
        
        Subject gp = new Subject();
        gp.id = "02739427";
        gp.subjectName = "Game Programming";
        gp.credits = 3;
    }
    
}
