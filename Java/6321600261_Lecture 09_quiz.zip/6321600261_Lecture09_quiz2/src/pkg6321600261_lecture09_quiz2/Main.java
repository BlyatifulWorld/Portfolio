/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg6321600261_lecture09_quiz2;

/**
 *
 * @author Tay
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Subject subject1 = new Subject();
        subject1.setId("02739214");
        subject1.setSubjectName("OOP");
        subject1.setCredit(4);
        
        Subject subject2 = new Subject();
        subject1.setId("02739435");
        subject1.setSubjectName("Data Mining");
        subject1.setCredit(3);
        
        Subject subject3 = new Subject();
        subject1.setId("02739427");
        subject1.setSubjectName("Game Programming");
        subject1.setCredit(3);
    }
    
}
