// ignore_for_file: must_be_immutable
import 'package:flutter/material.dart';

class FormHealthInfoPage extends StatefulWidget {
  FormHealthInfoPage({Key? key, required this.personName}) : super(key: key);

  String personName;

  @override
  State<FormHealthInfoPage> createState() => _FormHealthInfoPageState();
}

class _FormHealthInfoPageState extends State<FormHealthInfoPage> {
  
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Advisory for..${widget.personName}'),
        ),
        //TODO: Modify body part to show form for BMI calculation
        body: Container());
  }
}
